import { Stack, StackProps } from 'aws-cdk-lib';
import { Construct } from 'constructs';
export declare class CustomerCrudCdkApp01Stack extends Stack {
    private readonly appName;
    private customerTable;
    private customerApiLambda;
    private customerApi;
    constructor(scope: Construct, id: string, props?: StackProps);
    private createCustomerTable;
    private createCustomerApiLambda;
    private createCustomerApi;
    private addCustomerApiResources;
}
